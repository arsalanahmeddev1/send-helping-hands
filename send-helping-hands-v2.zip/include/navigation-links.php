<section class="navigation-sec bg-theme-default pt-41 pb-41">
    <div class="container-fluid">
        <div class="row ">
            <div class="nav-links">
                <ul class="d-flex justify-content-center gap-50">
                    <li><a href="" class="text-black fs-20">Who We Help</a></li>
                    <li><a href="" class="text-black fs-20">Our Services</a></li>
                    <li><a href="" class="text-black fs-20">How It Works</a></li>
                    <li><a href="" class="text-black fs-20">Why Helping Hands</a></li>
                    <li><a href="" class="text-black fs-20">Fees</a></li>
                    <li><a href="" class="text-black fs-20">Information Hubs</a></li>
                    <li><a href="" class="text-black fs-20">Testimonials</a></li>
                    <li><a href="" class="text-black fs-20">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>