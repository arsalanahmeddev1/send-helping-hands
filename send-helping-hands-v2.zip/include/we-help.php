     <div class="row">
         <div class="col-lg-4">
             <div class="image-box1 radius-20 mb-40">
                 <p class="fw-700 fs-28 text-white mb-0 img-box-desc">Anxiety</p>
             </div>
         </div>
         <div class="col-lg-4">
             <div class="image-box2 radius-20 mb-40">
                 <p class="fw-700 fs-28 text-white mb-0 img-box-desc">Autism</p>
             </div>
         </div>
         <div class="col-lg-4">
             <div class="image-box3 radius-20 mb-40">
                 <p class="fw-700 fs-28 text-white mb-0 img-box-desc">Dyslexia</p>
             </div>
         </div>
         <div class="col-lg-4">
             <div class="image-box4 radius-20">
                 <p class="fw-700 fs-28 text-white mb-0 img-box-desc">ADHD/ADD</p>
             </div>
         </div>
         <div class="col-lg-4">
             <div class="image-box5 radius-20">
                 <p class="fw-700 fs-28 text-white mb-0 img-box-desc">Working Memory</p>
             </div>
         </div>
         <div class="col-lg-4">
             <div class="image-box6 radius-20">
                 <p class="fw-700 fs-28 text-white mb-0 img-box-desc">Behaviour and/or PDA</p>
             </div>
         </div>
     </div>